.. _core_api_arm_compatiable_functions:

ARM Compatiable Functions
=========================

.. doxygengroup:: NMSIS_Core_ARMCompatiable_Functions
   :project: nmsis_core

