// See LICENSE for license details.
#ifndef _HBIRD_SDK_HAL_H
#define _HBIRD_SDK_HAL_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "board_hbird_eval.h"

#define SOC_DEBUG_UART      UART0

#ifndef HBIRD_BANNER
#define HBIRD_BANNER       1
#endif

#ifdef __cplusplus
}
#endif
#endif
