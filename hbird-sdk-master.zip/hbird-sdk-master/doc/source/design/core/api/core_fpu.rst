.. _core_api_fpu:

FPU Functions
=============

.. doxygengroup:: NMSIS_Core_FPU_Functions
   :project: nmsis_core

