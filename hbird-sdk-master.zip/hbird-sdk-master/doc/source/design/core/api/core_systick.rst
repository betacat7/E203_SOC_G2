.. _core_api_systick:

Systick Timer(SysTimer)
=======================

SysTimer API
------------

.. doxygengroup:: NMSIS_Core_SysTimer
   :project: nmsis_core
   :outline:
   :content-only:

.. doxygengroup:: NMSIS_Core_SysTimer
   :project: nmsis_core
