.. _develop:

Developer Guide
===============

.. toctree::
   :maxdepth: 3

   codestyle.rst
   buildsystem.rst
   appdev.rst
   builddoc.rst
