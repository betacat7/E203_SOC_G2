#include "config.h"

#ifdef __cplusplus
extern "C" {
#endif

extern volatile SPDP  theseSecs;
extern volatile SPDP  startSecs;
extern volatile SPDP  secs;
extern void start_time();
extern void end_time();
extern SPDP time();

#ifdef __cplusplus
};
#endif


