.. _core_api_core_intrinsic:

CPU Intrinsic Functions
=======================

.. doxygengroup:: NMSIS_Core_CPU_Intrinsic
   :project: nmsis_core
   :outline:
   :content-only:

.. doxygengroup:: NMSIS_Core_CPU_Intrinsic
   :project: nmsis_core

