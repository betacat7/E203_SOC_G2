.. _core_api_csr_access:

Core CSR Register Access
========================

.. doxygengroup:: NMSIS_Core_CSR_Register_Access
   :project: nmsis_core
