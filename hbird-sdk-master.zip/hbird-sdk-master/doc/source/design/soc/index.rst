.. _design_soc:

SoC
===

.. toctree::
   :maxdepth: 3

   hbird.rst
   hbirdv2.rst
